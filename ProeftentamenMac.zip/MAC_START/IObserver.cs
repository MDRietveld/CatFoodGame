﻿using System;

namespace ProefTentamen
{
	//Functie voor de Observers
	public interface IObserver
	{
		void OnFood();
	}
}

